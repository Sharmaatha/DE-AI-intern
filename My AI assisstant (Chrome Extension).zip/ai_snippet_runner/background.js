let lastSnippet = '';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'saveSnippet') lastSnippet = msg.text;
  if (msg.type === 'getSnippet') sendResponse({ text: lastSnippet });
  if (msg.type === 'clearSnippet') lastSnippet = '';
});