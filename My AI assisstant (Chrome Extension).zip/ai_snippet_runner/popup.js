document.addEventListener('DOMContentLoaded', () => {
  const snippetBox = document.getElementById('snippet');
  const copyBtn = document.getElementById('copy');
  const chatgptBtn = document.getElementById('chatgpt');
  const clearBtn = document.getElementById('clear');

  // Loading content
  chrome.runtime.sendMessage({ type: 'getSnippet' }, (res) => {
    if (res && res.text) snippetBox.innerText = res.text;
  });

  //(copy)
  copyBtn.addEventListener('click', () => {
    const text = snippetBox.innerText.trim();
    if (!text || text === 'Select code on any page...') {
      alert('No snippet selected or typed!');
      return;
    }
    const temp = document.createElement('textarea');
    temp.value = text;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand('copy');
    document.body.removeChild(temp);

    copyBtn.innerText = 'Copied!';
    setTimeout(() => (copyBtn.innerText = 'Copy'), 1500);
  });

  // chatgpt
  chatgptBtn.addEventListener('click', () => {
    const text = snippetBox.innerText.trim();
    if (!text || text === 'Select code on any page...') {
      alert('No snippet selected or typed!');
      return;
    }
    const url = 'https://chat.openai.com/?q=' + encodeURIComponent(text);
    chrome.tabs.create({ url });
  });

  //(clear)
  clearBtn.addEventListener('click', () => {
    snippetBox.innerText = 'Select code on any page...';
    chrome.runtime.sendMessage({ type: 'clearSnippet' });
    clearBtn.innerText = 'Cleared!';
    setTimeout(() => (clearBtn.innerText = 'Clear'), 1500);
  });
});