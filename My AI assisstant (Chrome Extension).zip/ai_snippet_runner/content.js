document.addEventListener('mouseup', () => {
  const selection = window.getSelection().toString().trim();
  if (selection.length > 5) {
    chrome.runtime.sendMessage({ type: 'saveSnippet', text: selection });
  }
});